var universe = require('./universe');
universe.start();
console.log('The answer is' + universe.answer);
phantom.exit();
